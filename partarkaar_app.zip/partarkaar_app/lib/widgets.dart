import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'api.dart';
import 'screens/article.dart';

const kRed = Color(0xFFFF0000);

Future<void> openUrl(String u) async {
  final uri = Uri.tryParse(u);
  if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
}

void openStory(BuildContext c, Story s) =>
    Navigator.of(c).push(MaterialPageRoute(builder: (_) => ArticleScreen(id: s.id, preview: s)));

class Pic extends StatelessWidget {
  final String url;
  final double? h;
  const Pic(this.url, {super.key, this.h});
  @override
  Widget build(BuildContext context) => CachedNetworkImage(
        imageUrl: url, height: h, width: double.infinity, fit: BoxFit.cover,
        placeholder: (_, __) => Container(height: h, color: Colors.black12),
        errorWidget: (_, __, ___) => Container(height: h, color: Colors.black12, child: const Icon(Icons.image_not_supported_outlined)),
      );
}

class SectionTitle extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  const SectionTitle(this.text, {super.key, this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 22, 16, 10),
          child: Row(children: [
            Expanded(child: Text(text.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1, fontSize: 14))),
            if (onTap != null) const Icon(Icons.chevron_right, size: 20),
          ]),
        ),
      );
}

class LiveTag extends StatelessWidget {
  const LiveTag({super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        color: kRed,
        child: const Text('LIVE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11, letterSpacing: 1)),
      );
}

/// Big story (top of the home page)
class HeroCard extends StatelessWidget {
  final Story s;
  const HeroCard(this.s, {super.key});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: () => openStory(context, s),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Pic(s.image, h: 230),
          Container(
            color: Colors.black,
            padding: const EdgeInsets.all(16),
            width: double.infinity,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (s.live) const Padding(padding: EdgeInsets.only(bottom: 8), child: LiveTag()),
              Text(s.title, style: const TextStyle(color: Colors.white, fontSize: 24, height: 1.2, fontWeight: FontWeight.w700, fontFamily: 'serif')),
              if (s.dek.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(s.dek, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 15))),
            ]),
          ),
        ]),
      );
}

/// Normal story card (picture on top)
class StoryCard extends StatelessWidget {
  final Story s;
  const StoryCard(this.s, {super.key});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: () => openStory(context, s),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Pic(s.image, h: 190),
            const SizedBox(height: 10),
            if (s.category.isNotEmpty) Text(s.category.toUpperCase(), style: const TextStyle(color: kRed, fontWeight: FontWeight.w800, fontSize: 11, letterSpacing: .8)),
            const SizedBox(height: 4),
            Text(s.title, style: const TextStyle(fontSize: 19, height: 1.25, fontWeight: FontWeight.w700, fontFamily: 'serif')),
            const SizedBox(height: 6),
            Text([if (s.author.isNotEmpty) s.author, ago(s.publishedAt)].join('  ·  '), style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
        ),
      );
}

/// Small card used in swipe rows
class MiniCard extends StatelessWidget {
  final Story s;
  const MiniCard(this.s, {super.key});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: () => openStory(context, s),
        child: SizedBox(
          width: 220,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Pic(s.image, h: 124),
            const SizedBox(height: 8),
            Text(s.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, height: 1.25, fontWeight: FontWeight.w700, fontFamily: 'serif')),
            const SizedBox(height: 4),
            Text(ago(s.publishedAt), style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
        ),
      );
}

class MiniRow extends StatelessWidget {
  final List<Story> items;
  const MiniRow(this.items, {super.key});
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 216,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(width: 14),
          itemBuilder: (_, i) => MiniCard(items[i]),
        ),
      );
}

class ErrorBox extends StatelessWidget {
  final Object error;
  final VoidCallback retry;
  const ErrorBox(this.error, this.retry, {super.key});
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.wifi_off, size: 40),
            const SizedBox(height: 12),
            Text('Could not load.\n${error.toString().replaceFirst('Exception: ', '')}', textAlign: TextAlign.center),
            const SizedBox(height: 14),
            FilledButton(onPressed: retry, style: FilledButton.styleFrom(backgroundColor: kRed, shape: const RoundedRectangleBorder()), child: const Text('Try again')),
          ]),
        ),
      );
}

/// Text with **bold**, *italic* and [links](https://...)
class RichInline extends StatefulWidget {
  final String text;
  final TextStyle style;
  const RichInline(this.text, {super.key, required this.style});
  @override
  State<RichInline> createState() => _RichInlineState();
}

class _RichInlineState extends State<RichInline> {
  final List<TapGestureRecognizer> _r = [];
  @override
  void dispose() {
    for (final r in _r) {
      r.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    for (final r in _r) {
      r.dispose();
    }
    _r.clear();
    final re = RegExp(r'\*\*(.+?)\*\*|\*(.+?)\*|\[([^\]]{1,200})\]\(([^)\s]+)\)', dotAll: true);
    final spans = <InlineSpan>[];
    var i = 0;
    final t = widget.text;
    for (final m in re.allMatches(t)) {
      if (m.start > i) spans.add(TextSpan(text: t.substring(i, m.start)));
      if (m.group(1) != null) {
        spans.add(TextSpan(text: m.group(1), style: const TextStyle(fontWeight: FontWeight.w700)));
      } else if (m.group(2) != null) {
        spans.add(TextSpan(text: m.group(2), style: const TextStyle(fontStyle: FontStyle.italic)));
      } else {
        final url = m.group(4)!;
        final rec = TapGestureRecognizer()..onTap = () => openUrl(url);
        _r.add(rec);
        spans.add(TextSpan(text: m.group(3), recognizer: rec, style: const TextStyle(color: kRed, decoration: TextDecoration.underline)));
      }
      i = m.end;
    }
    if (i < t.length) spans.add(TextSpan(text: t.substring(i)));
    return Text.rich(TextSpan(children: spans, style: widget.style));
  }
}
