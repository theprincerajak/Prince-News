import 'package:flutter/material.dart';
import 'api.dart';
import 'config.dart';
import 'screens/home.dart';
import 'screens/search.dart';
import 'screens/section.dart';
import 'widgets.dart';

void main() => runApp(const NewsApp());

class NewsApp extends StatelessWidget {
  const NewsApp({super.key});

  ThemeData _theme(Brightness b) {
    final dark = b == Brightness.dark;
    return ThemeData(
      useMaterial3: true,
      brightness: b,
      colorScheme: ColorScheme.fromSeed(seedColor: kRed, brightness: b, primary: kRed),
      scaffoldBackgroundColor: dark ? Colors.black : Colors.white,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.black, foregroundColor: Colors.white, elevation: 0, centerTitle: false,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: dark ? const Color(0xFF111111) : Colors.white,
        indicatorColor: kRed.withOpacity(.15),
        surfaceTintColor: Colors.transparent,
      ),
    );
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: Config.appName,
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;
  late Future<void> _cfg = Api.loadConfig().catchError((_) {});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: _tab == 2 ? null : AppBar(
          title: Text(Config.appName, style: const TextStyle(fontFamily: 'serif', fontWeight: FontWeight.w800, fontSize: 24)),
          actions: [IconButton(icon: const Icon(Icons.search), onPressed: () => setState(() => _tab = 2))],
        ),
        body: FutureBuilder<void>(
          future: _cfg,
          builder: (c, _) => IndexedStack(index: _tab, children: [
            const HomeScreen(),
            CategoriesScreen(),
            SearchScreen(),
          ]),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() { _tab = i; if (i == 1) _cfg = Api.loadConfig().catchError((_) {}); }),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: kRed), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view, color: kRed), label: 'Categories'),
            NavigationDestination(icon: Icon(Icons.search), selectedIcon: Icon(Icons.search, color: kRed), label: 'Search'),
          ],
        ),
      );
}

class CategoriesScreen extends StatelessWidget {
  CategoriesScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(children: [
        for (final s in Api.sections)
          ListTile(
            title: Text(s.name.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SectionScreen(s.id, s.name))),
          ),
        if (Api.sections.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('No categories yet.'))),
      ]);
}

