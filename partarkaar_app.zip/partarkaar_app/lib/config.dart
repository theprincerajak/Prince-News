class Config {
  /// >>> CHANGE THIS to your live website address (keep https:// and the ending /) <<<
  static const String siteUrl = 'https://YOURDOMAIN.example/';
  static const String appName = 'Partarkaar';
}
