import 'package:flutter/material.dart';
import '../api.dart';
import '../widgets.dart';

/// A list of stories that loads more when you press "Load more". Used for categories.
class SectionScreen extends StatefulWidget {
  final String id, name;
  const SectionScreen(this.id, this.name, {super.key});
  @override
  State<SectionScreen> createState() => _SectionScreenState();
}

class _SectionScreenState extends State<SectionScreen> {
  final List<Story> _items = [];
  bool _more = true, _busy = false, _first = true;
  Object? _err;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (_busy) return;
    setState(() { _busy = true; _err = null; });
    try {
      final j = await Api.get('section', {'s': widget.id, 'offset': '${_items.length}', 'limit': '10'});
      _items.addAll(storyList(j['items']));
      _more = j['more'] == true;
    } catch (e) {
      _err = e;
    }
    if (mounted) setState(() { _busy = false; _first = false; });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.name.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1, fontSize: 16))),
        body: _first && _busy
            ? const Center(child: CircularProgressIndicator(color: kRed))
            : (_err != null && _items.isEmpty)
                ? ErrorBox(_err!, _load)
                : ListView(padding: const EdgeInsets.only(top: 16, bottom: 30), children: [
                    ..._items.map(StoryCard.new),
                    if (_more) Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: OutlinedButton(
                        onPressed: _busy ? null : _load,
                        style: OutlinedButton.styleFrom(shape: const RoundedRectangleBorder(), foregroundColor: kRed, side: const BorderSide(color: kRed), padding: const EdgeInsets.all(14)),
                        child: Text(_busy ? 'Loading...' : 'Load more'),
                      ),
                    ),
                    if (_err != null && _items.isNotEmpty) Padding(padding: const EdgeInsets.all(16), child: Text('${_err}'.replaceFirst('Exception: ', ''), textAlign: TextAlign.center)),
                  ]),
      );
}
