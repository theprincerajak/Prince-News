import 'package:flutter/material.dart';
import '../api.dart';
import '../widgets.dart';

class SearchScreen extends StatefulWidget {
  SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _q = TextEditingController();
  final List<Story> _items = [];
  String _cat = '', _sort = 'new', _when = '', _term = '';
  bool _busy = false, _more = false, _done = false;
  Object? _err;
  int _total = 0;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _run({bool reset = true}) async {
    if (_busy) return;
    if (reset) { _items.clear(); _term = _q.text.trim(); }
    setState(() { _busy = true; _err = null; });
    try {
      final j = await Api.get('search', {'q': _term, 'cat': _cat, 'sort': _sort, 'when': _when, 'offset': '${_items.length}', 'limit': '10'});
      _items.addAll(storyList(j['items']));
      _more = j['more'] == true;
      _total = (j['total'] as num?)?.toInt() ?? _items.length;
      _done = true;
    } catch (e) {
      _err = e;
    }
    if (mounted) setState(() => _busy = false);
  }

  Widget _drop(String label, String value, Map<String, String> opts, ValueChanged<String> on) => Expanded(
        child: DropdownButtonFormField<String>(
          value: value,
          isExpanded: true,
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder(borderRadius: BorderRadius.zero), contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8)),
          items: opts.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value, overflow: TextOverflow.ellipsis))).toList(),
          onChanged: (v) { on(v ?? ''); _run(); },
        ),
      );

  @override
  Widget build(BuildContext context) {
    final cats = {'': 'All categories', for (final s in Api.sections) s.id: s.name};
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _q,
          textInputAction: TextInputAction.search,
          onSubmitted: (_) => _run(),
          decoration: const InputDecoration(hintText: 'Search stories', border: InputBorder.none),
        ),
        actions: [IconButton(icon: const Icon(Icons.search), onPressed: _run)],
      ),
      body: ListView(padding: const EdgeInsets.only(top: 12, bottom: 30), children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(children: [
            Row(children: [
              _drop('Category', _cat, cats, (v) => _cat = v),
              const SizedBox(width: 10),
              _drop('Sort by', _sort, const {'new': 'Newest', 'old': 'Oldest', 'views': 'Most viewed'}, (v) => _sort = v),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              _drop('Date', _when, const {'': 'Any time', 'day': 'Past day', 'week': 'Past week', 'month': 'Past month', 'year': 'Past year'}, (v) => _when = v),
              const Expanded(child: SizedBox()),
            ]),
          ]),
        ),
        const SizedBox(height: 14),
        if (_busy && _items.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator(color: kRed))),
        if (_err != null) Padding(padding: const EdgeInsets.all(16), child: Text('${_err}'.replaceFirst('Exception: ', ''), textAlign: TextAlign.center)),
        if (_done && _items.isEmpty && !_busy && _err == null) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('No stories match your search.'))),
        if (_items.isNotEmpty) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 12), child: Text('$_total ${_total == 1 ? 'story' : 'stories'}', style: const TextStyle(color: Colors.grey))),
        ..._items.map(StoryCard.new),
        if (_more) Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: OutlinedButton(
            onPressed: _busy ? null : () => _run(reset: false),
            style: OutlinedButton.styleFrom(shape: const RoundedRectangleBorder(), foregroundColor: kRed, side: const BorderSide(color: kRed), padding: const EdgeInsets.all(14)),
            child: Text(_busy ? 'Loading...' : 'Load more'),
          ),
        ),
      ]),
    );
  }
}
