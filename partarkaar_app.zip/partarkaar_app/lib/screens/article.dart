import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../api.dart';
import '../widgets.dart';

class ArticleScreen extends StatefulWidget {
  final String id;
  final Story? preview;
  const ArticleScreen({super.key, required this.id, this.preview});
  @override
  State<ArticleScreen> createState() => _ArticleScreenState();
}

class _ArticleScreenState extends State<ArticleScreen> {
  late Future<Map<String, dynamic>> _f = Api.get('article', {'id': widget.id});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: FutureBuilder<Map<String, dynamic>>(
          future: _f,
          builder: (c, snap) {
            final loading = snap.connectionState != ConnectionState.done;
            final j = snap.data;
            final s = j != null ? Story.fromJson(j) : widget.preview;
            return CustomScrollView(slivers: [
              SliverAppBar(
                pinned: true,
                title: s == null ? null : Text(s.sectionName.toUpperCase(), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1)),
                actions: [if (s != null) IconButton(icon: const Icon(Icons.share_outlined), onPressed: () => Share.share('${s.title}\n${s.url}'))],
              ),
              if (snap.hasError) SliverFillRemaining(child: ErrorBox(snap.error!, () => setState(() => _f = Api.get('article', {'id': widget.id}))))
              else ...[
                if (s != null) SliverToBoxAdapter(child: _head(s, j)),
                if (loading) const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator(color: kRed)))),
                if (j != null) SliverList(delegate: SliverChildListDelegate([
                  ...((j['blocks'] ?? []) as List).map((b) => Block(b as Map<String, dynamic>)),
                  _related(storyList(j['related'])),
                  const SizedBox(height: 40),
                ])),
              ],
            ]);
          },
        ),
      );

  Widget _head(Story s, Map<String, dynamic>? j) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Pic(s.image, h: 230),
        if (j != null && '${j['image_caption'] ?? ''}'.isNotEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(16, 6, 16, 0), child: Text('${j['image_caption']}', style: const TextStyle(fontSize: 12, color: Colors.grey))),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (s.live) const Padding(padding: EdgeInsets.only(bottom: 8), child: LiveTag()),
            if (s.category.isNotEmpty) Text(s.category.toUpperCase(), style: const TextStyle(color: kRed, fontWeight: FontWeight.w800, fontSize: 12, letterSpacing: .8)),
            const SizedBox(height: 6),
            Text(s.title, style: const TextStyle(fontSize: 28, height: 1.2, fontWeight: FontWeight.w800, fontFamily: 'serif')),
            if (s.dek.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(s.dek, style: const TextStyle(fontSize: 17, height: 1.4, color: Colors.grey))),
            const SizedBox(height: 12),
            Text([if (s.author.isNotEmpty) s.author, ago(s.publishedAt), '${s.minutes} min read'].join('  ·  '), style: const TextStyle(fontSize: 12, color: Colors.grey)),
            const Divider(height: 28),
          ]),
        ),
      ]);

  Widget _related(List<Story> l) => l.isEmpty ? const SizedBox() : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SectionTitle('You may also like'), MiniRow(l)]);
}

/// One piece of a story (paragraph, picture, quote...)
class Block extends StatelessWidget {
  final Map<String, dynamic> b;
  const Block(this.b, {super.key});

  static const _body = TextStyle(fontSize: 18, height: 1.6, fontFamily: 'serif');

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    Widget pad(Widget w, [double v = 8]) => Padding(padding: EdgeInsets.fromLTRB(16, v, 16, v), child: w);
    switch (b['t']) {
      case 'p':
        return pad(RichInline('${b['text']}', style: _body.copyWith(color: cs.onSurface)));
      case 'h':
        return pad(Text('${b['text']}', style: TextStyle(fontSize: b['lvl'] == 3 ? 19 : 23, fontWeight: FontWeight.w800, height: 1.25)), 14);
      case 'img':
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Pic('${b['src']}')),
          if ('${b['cap'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 8), child: Text('${b['cap']}', style: const TextStyle(fontSize: 12, color: Colors.grey))),
        ]);
      case 'gal':
        final items = (b['items'] as List).cast<Map<String, dynamic>>();
        return pad(GridView.count(
          crossAxisCount: 2, mainAxisSpacing: 6, crossAxisSpacing: 6, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          children: items.map((i) => Pic('${i['src']}')).toList(),
        ));
      case 'vid':
        return pad(OutlinedButton.icon(
          onPressed: () => openUrl('${b['url']}'),
          icon: const Icon(Icons.play_circle_outline),
          label: Text('${b['cap']}'.isNotEmpty ? '${b['cap']}' : 'Watch video'),
          style: OutlinedButton.styleFrom(shape: const RoundedRectangleBorder(), foregroundColor: kRed, side: const BorderSide(color: kRed), padding: const EdgeInsets.all(14)),
        ));
      case 'quote':
        return pad(Container(
          padding: const EdgeInsets.only(left: 14),
          decoration: const BoxDecoration(border: Border(left: BorderSide(color: kRed, width: 3))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            RichInline('${b['text']}', style: _body.copyWith(fontSize: 21, fontStyle: FontStyle.italic, color: cs.onSurface)),
            if ('${b['by'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('— ${b['by']}', style: const TextStyle(fontSize: 13, color: Colors.grey))),
          ]),
        ), 12);
      case 'list':
        final it = (b['items'] as List).cast<String>();
        final ord = b['ordered'] == true;
        return pad(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          for (var i = 0; i < it.length; i++)
            Padding(padding: const EdgeInsets.only(bottom: 6), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(width: 26, child: Text(ord ? '${i + 1}.' : '•', style: _body)),
              Expanded(child: RichInline(it[i], style: _body.copyWith(color: cs.onSurface))),
            ])),
        ]));
      case 'call':
        final tone = '${b['tone']}';
        final col = tone == 'warn' ? Colors.orange : tone == 'key' ? kRed : Colors.blueGrey;
        return pad(Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: col.withOpacity(.1), border: Border(left: BorderSide(color: col, width: 4))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if ('${b['title'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 4), child: Text('${b['title']}', style: const TextStyle(fontWeight: FontWeight.w800))),
            RichInline('${b['text']}', style: TextStyle(fontSize: 16, height: 1.5, color: cs.onSurface)),
          ]),
        ));
      case 'link':
        final style = '${b['style']}';
        final label = '${b['title'] ?? ''}'.isNotEmpty ? '${b['title']}' : '${b['url']}';
        if (style == 'text') return pad(GestureDetector(onTap: () => openUrl('${b['url']}'), child: Text(label, style: const TextStyle(color: kRed, decoration: TextDecoration.underline, fontSize: 17))));
        return pad(InkWell(
          onTap: () => openUrl('${b['url']}'),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(border: Border.all(color: Colors.black26)),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
                if ('${b['desc'] ?? ''}'.isNotEmpty) Text('${b['desc']}', style: const TextStyle(fontSize: 13, color: Colors.grey)),
              ])),
              const Icon(Icons.open_in_new, size: 18),
            ]),
          ),
        ));
      case 'tweet':
        return pad(TextButton.icon(onPressed: () => openUrl('${b['url']}'), icon: const Icon(Icons.open_in_new, size: 18), label: const Text('View this post on X'), style: TextButton.styleFrom(foregroundColor: kRed)));
      case 'hr':
        return const Divider(height: 30, indent: 16, endIndent: 16);
    }
    return const SizedBox();
  }
}
