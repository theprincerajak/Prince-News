import 'package:flutter/material.dart';
import '../api.dart';
import '../widgets.dart';
import 'section.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<Map<String, dynamic>> _f = Api.get('home');
  Future<void> _reload() async {
    setState(() => _f = Api.get('home'));
    await _f.catchError((_) => <String, dynamic>{});
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: _f,
        builder: (c, snap) {
          if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator(color: kRed));
          if (snap.hasError) return ErrorBox(snap.error!, _reload);
          final j = snap.data!;
          final hero = j['hero'] == null ? null : Story.fromJson(j['hero'] as Map<String, dynamic>);
          final latest = storyList(j['latest']);
          final most = storyList(j['most_read']);
          final secs = (j['sections'] ?? []) as List;
          return RefreshIndicator(
            color: kRed,
            onRefresh: _reload,
            child: ListView(padding: EdgeInsets.zero, children: [
              if (hero != null) HeroCard(hero),
              if (latest.isNotEmpty) ...[const SectionTitle('Latest'), ...latest.map(StoryCard.new)],
              if (most.isNotEmpty) ...[const SectionTitle('Most read'), MiniRow(most)],
              for (final s in secs) ...[
                SectionTitle('${s['name']}', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SectionScreen('${s['id']}', '${s['name']}')))),
                MiniRow(storyList(s['items'])),
              ],
              const SizedBox(height: 30),
            ]),
          );
        },
      );
}
