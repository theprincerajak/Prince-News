import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';

class Story {
  final String id, title, dek, category, section, sectionName, image, author, publishedAt, url;
  final int minutes;
  final bool live;
  Story.fromJson(Map<String, dynamic> j)
      : id = '${j['id']}',
        title = '${j['title'] ?? ''}',
        dek = '${j['dek'] ?? ''}',
        category = '${j['category'] ?? ''}',
        section = '${j['section'] ?? ''}',
        sectionName = '${j['section_name'] ?? ''}',
        image = '${j['image'] ?? ''}',
        author = '${j['author'] ?? ''}',
        publishedAt = '${j['published_at'] ?? ''}',
        url = '${j['url'] ?? ''}',
        minutes = (j['reading_minutes'] as num?)?.toInt() ?? 1,
        live = j['live'] == true;
}

List<Story> storyList(dynamic l) =>
    ((l ?? []) as List).map((e) => Story.fromJson(e as Map<String, dynamic>)).toList();

class Section {
  final String id, name;
  Section(this.id, this.name);
}

class Api {
  static Future<Map<String, dynamic>> get(String r, [Map<String, String> q = const {}]) async {
    final uri = Uri.parse('${Config.siteUrl}api.php').replace(queryParameters: {'r': r, 'i': '1', ...q});
    final res = await http.get(uri, headers: {'Accept': 'application/json'}).timeout(const Duration(seconds: 20));
    final body = utf8.decode(res.bodyBytes);
    dynamic j;
    try {
      j = jsonDecode(body);
    } catch (_) {
      throw Exception('The website did not return app data. Check siteUrl in config.dart, and that api.php is uploaded.');
    }
    if (res.statusCode != 200) throw Exception((j is Map ? j['error'] : null) ?? 'Error ${res.statusCode}');
    return j as Map<String, dynamic>;
  }

  static List<Section> sections = [];
  static Future<void> loadConfig() async {
    final j = await get('config');
    sections = ((j['sections'] ?? []) as List).map((s) => Section('${s['id']}', '${s['name']}')).toList();
  }
}

String ago(String iso) {
  final t = DateTime.tryParse(iso);
  if (t == null) return '';
  final d = DateTime.now().difference(t.toLocal());
  if (d.inMinutes < 1) return 'Just now';
  if (d.inMinutes < 60) return '${d.inMinutes} min ago';
  if (d.inHours < 24) return '${d.inHours} h ago';
  if (d.inDays < 7) return '${d.inDays} d ago';
  const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final l = t.toLocal();
  return '${m[l.month - 1]} ${l.day}, ${l.year}';
}
