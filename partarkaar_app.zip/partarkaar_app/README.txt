PARTARKAAR APP (Flutter: one project makes the Android app and the iPhone app)

BEFORE YOU START
- Upload meridian-api-update.zip to your website first, and check yourdomain/api.php?r=home shows your stories.

ONE-TIME SETUP (on a computer)
1. Install Flutter: https://docs.flutter.dev/get-started/install  (follow the page for your computer,
   including Android Studio for Android; Xcode on a Mac is needed only for iPhone).
2. Open a terminal in THIS folder and run:   flutter create --org com.partarkaar --project-name partarkaar_app .
   (this adds the android and ios folders; it keeps the lib and pubspec files from here)
3. Open lib/config.dart and set siteUrl to your website (https://... with the ending /).
4. Android only: open android/app/src/main/AndroidManifest.xml and add these two things:
   - right after <manifest ...> add:   <uses-permission android:name="android.permission.INTERNET"/>
   - right before <application ...> add:
       <queries><intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent></queries>
5. Run:   flutter pub get
6. Make the app icon:   dart run flutter_launcher_icons

TRY IT
- Connect an Android phone (USB debugging on) and run:   flutter run

MAKE THE APK
- flutter build apk --release
- The file is build/app/outputs/flutter-apk/app-release.apk
- Upload it in Admin > Header & menu > Download app > Upload .apk file > Save.
- For the Google Play Store use:   flutter build appbundle   (you must sign it with your own key:
  https://docs.flutter.dev/deployment/android#sign-the-app )  Keep the key file and password safe.

NO COMPUTER SETUP: BUILD THE APK ONLINE WITH GITHUB (free)
1. Create a free account at github.com and press New repository (Private is fine).
2. Press "uploading an existing file" and drag in everything from INSIDE this folder
   (lib, assets, pubspec.yaml, and the hidden .github folder). If your browser skips the hidden
   .github folder, use Add file > Create new file, type  .github/workflows/build-apk.yml  as the name
   and paste the contents of that file.
3. Open lib/config.dart on GitHub, press the pencil icon, set siteUrl to your website, and commit.
4. Open the Actions tab > Build APK > Run workflow. Wait about 5 to 10 minutes.
5. Open the finished run, scroll to Artifacts, and download partarkaar-apk. Unzip it: app-release.apk is inside.
6. Upload it in your admin: Header & menu > Download app > Upload .apk file > Save.
Note: each online build is signed with a new test key, so uninstall the old version before installing a new one.
