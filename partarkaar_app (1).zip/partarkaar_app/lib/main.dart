import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'api.dart';
import 'config.dart';
import 'screens/home.dart';
import 'screens/search.dart';
import 'screens/section.dart';
import 'widgets.dart';

void main() => runApp(const NewsApp());

class NewsApp extends StatelessWidget {
  const NewsApp({super.key});

  ThemeData _theme(Brightness b) {
    final dark = b == Brightness.dark;
    return ThemeData(
      useMaterial3: true,
      brightness: b,
      colorScheme: ColorScheme.fromSeed(seedColor: kRed, brightness: b, primary: kRed),
      scaffoldBackgroundColor: dark ? Colors.black : Colors.white,
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.black, foregroundColor: Colors.white, elevation: 0, centerTitle: false,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: dark ? const Color(0xFF111111) : Colors.white,
        indicatorColor: kRed.withOpacity(.15),
        surfaceTintColor: Colors.transparent,
      ),
    );
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: Config.appName,
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        home: const Gate(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;
  late Future<void> _cfg = Api.loadConfig().catchError((_) {});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: _tab == 2 ? null : AppBar(
          title: Text(Config.appName, style: const TextStyle(fontFamily: 'serif', fontWeight: FontWeight.w800, fontSize: 24)),
          actions: [IconButton(icon: const Icon(Icons.search), onPressed: () => setState(() => _tab = 2))],
        ),
        body: FutureBuilder<void>(
          future: _cfg,
          builder: (c, _) => IndexedStack(index: _tab, children: [
            const HomeScreen(),
            CategoriesScreen(),
            SearchScreen(),
          ]),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() { _tab = i; if (i == 1) _cfg = Api.loadConfig().catchError((_) {}); }),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: kRed), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view, color: kRed), label: 'Categories'),
            NavigationDestination(icon: Icon(Icons.search), selectedIcon: Icon(Icons.search, color: kRed), label: 'Search'),
          ],
        ),
      );
}

class CategoriesScreen extends StatelessWidget {
  CategoriesScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(children: [
        for (final s in Api.sections)
          ListTile(
            title: Text(s.name.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SectionScreen(s.id, s.name))),
          ),
        if (Api.sections.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('No categories yet.'))),
      ]);
}


/// Tries the app feed first. If the host blocks it (some free hosts do), shows the website inside the app instead.
class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  late final Future<bool> _ok = Api.loadConfig().then((_) => true).catchError((_) => false);

  @override
  Widget build(BuildContext context) => FutureBuilder<bool>(
        future: _ok,
        builder: (c, s) {
          if (!s.hasData) {
            return Scaffold(
              backgroundColor: Colors.black,
              body: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(Config.appName, style: const TextStyle(color: Colors.white, fontFamily: 'serif', fontWeight: FontWeight.w800, fontSize: 30)),
                  const SizedBox(height: 18),
                  const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(color: kRed, strokeWidth: 3)),
                ]),
              ),
            );
          }
          return s.data! ? const Shell() : const WebApp();
        },
      );
}

/// The website shown full-screen inside the app
class WebApp extends StatefulWidget {
  const WebApp({super.key});
  @override
  State<WebApp> createState() => _WebAppState();
}

class _WebAppState extends State<WebApp> {
  late final WebViewController _c;

  @override
  void initState() {
    super.initState();
    final host = Uri.parse(Config.siteUrl).host;
    _c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(NavigationDelegate(onNavigationRequest: (r) {
        final u = Uri.tryParse(r.url);
        if (u == null || u.host == host || u.scheme == 'about' || u.scheme == 'data' || u.scheme == 'blob') return NavigationDecision.navigate;
        openUrl(r.url);
        return NavigationDecision.prevent;
      }))
      ..loadRequest(Uri.parse('${Config.siteUrl}?source=app'));
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, _) async {
          if (didPop) return;
          if (await _c.canGoBack()) {
            _c.goBack();
          } else {
            SystemNavigator.pop();
          }
        },
        child: Scaffold(backgroundColor: Colors.black, body: SafeArea(child: WebViewWidget(controller: _c))),
      );
}
